import logo from './logo.svg';
import './App.css';
import Landingpage from './Components/Landingpage';
// import Paginate from './Components/Paginate';

function App() {
  return (
    <Landingpage/>
    // <Paginate itemsPerPage={4} />
  );
}

export default App;
